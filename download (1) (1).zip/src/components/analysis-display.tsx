"use client";

import Image from "next/image";
import { ArrowLeft, Sprout, FlaskConical, HeartPulse } from "lucide-react";
import type { IdentifyLeafSpeciesOutput } from "@/ai/flows/identify-leaf-species";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

type AnalysisDisplayProps = {
  result: IdentifyLeafSpeciesOutput;
  imagePreview: string;
  onReset: () => void;
};

const InfoItem = ({ label, value }: { label: string; value: string }) => (
  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
    <p className="font-semibold text-muted-foreground">{label}</p>
    <p className="sm:text-right font-medium">{value}</p>
  </div>
);

export default function AnalysisDisplay({
  result,
  imagePreview,
  onReset,
}: AnalysisDisplayProps) {
  return (
    <div className="flex flex-col items-center gap-8 w-full">
      <div className="relative w-full max-w-sm aspect-square">
        <Image
          src={imagePreview}
          alt="Analyzed leaf"
          layout="fill"
          objectFit="cover"
          className="rounded-xl shadow-2xl"
        />
      </div>

      <div className="w-full grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Species Information */}
        <Card className="shadow-lg animate-in fade-in-0 zoom-in-95 duration-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Sprout className="h-6 w-6 text-primary" />
              </div>
              <span className="font-headline">Species Information</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <InfoItem label="Common Name" value={result.commonName} />
            <InfoItem label="Biological Name" value={result.biologicalName} />
          </CardContent>
        </Card>

        {/* Medicinal Properties */}
        <Card className="shadow-lg animate-in fade-in-0 zoom-in-95 duration-500 delay-100">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
               <div className="p-2 bg-accent/10 rounded-lg">
                <FlaskConical className="h-6 w-6 text-accent" />
               </div>
              <span className="font-headline">Medicinal Properties</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-foreground/90 leading-relaxed">
              {result.medicinalUses}
            </p>
          </CardContent>
        </Card>

        {/* Health Status */}
        <Card className="shadow-lg animate-in fade-in-0 zoom-in-95 duration-500 delay-200 md:col-span-2 lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <HeartPulse className="h-6 w-6 text-primary" />
              </div>
              <span className="font-headline">Health Status</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold text-muted-foreground mb-1">Disease Identification</h4>
              <p>{result.diseaseIdentification}</p>
            </div>
            <div>
              <h4 className="font-semibold text-muted-foreground mb-1">Curative Actions</h4>
              <p className="text-foreground/90 leading-relaxed">
                {result.curativeActions}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Button onClick={onReset} size="lg" className="mt-4" variant="outline">
        <ArrowLeft className="mr-2 h-5 w-5" />
        Analyze Another Leaf
      </Button>
    </div>
  );
}
