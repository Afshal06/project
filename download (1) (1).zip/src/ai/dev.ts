import { config } from 'dotenv';
config();

import '@/ai/flows/diagnose-leaf-disease.ts';
import '@/ai/flows/identify-leaf-species.ts';
import '@/ai/flows/provide-medicinal-uses.ts';