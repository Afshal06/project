'use server';

/**
 * @fileOverview An AI agent to identify leaf species from an image.
 *
 * - identifyLeafSpecies - A function that handles the leaf identification process.
 * - IdentifyLeafSpeciesInput - The input type for the identifyLeafSpecies function.
 * - IdentifyLeafSpeciesOutput - The return type for the identifyLeafSpecies function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const IdentifyLeafSpeciesInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      'A photo of a leaf, as a data URI that must include a MIME type and use Base64 encoding. Expected format: \'data:<mimetype>;base64,<encoded_data>\'.' 
    ),
});
export type IdentifyLeafSpeciesInput = z.infer<typeof IdentifyLeafSpeciesInputSchema>;

const IdentifyLeafSpeciesOutputSchema = z.object({
  commonName: z.string().describe('The common name of the identified leaf.'),
  biologicalName: z.string().describe('The biological name of the identified leaf.'),
  medicinalUses: z.string().describe('Traditional medicinal uses of the leaf.'),
  diseaseIdentification: z.string().describe('Potential diseases or abnormalities of the leaf.'),
  curativeActions: z.string().describe('Curative actions for identified diseases.'),
});
export type IdentifyLeafSpeciesOutput = z.infer<typeof IdentifyLeafSpeciesOutputSchema>;

export async function identifyLeafSpecies(input: IdentifyLeafSpeciesInput): Promise<IdentifyLeafSpeciesOutput> {
  return identifyLeafSpeciesFlow(input);
}

const identifyLeafSpeciesPrompt = ai.definePrompt({
  name: 'identifyLeafSpeciesPrompt',
  input: {schema: IdentifyLeafSpeciesInputSchema},
  output: {schema: IdentifyLeafSpeciesOutputSchema},
  prompt: `You are an expert botanist specializing in leaf identification and disease diagnosis.

You will analyze the provided image of a leaf and identify its species, provide its biological name, and detail its medicinal uses.

Additionally, you will analyze the leaf for any signs of disease or abnormalities and suggest potential curative actions.

Analyze the following leaf image:

{{media url=photoDataUri}}
`,
});

const identifyLeafSpeciesFlow = ai.defineFlow(
  {
    name: 'identifyLeafSpeciesFlow',
    inputSchema: IdentifyLeafSpeciesInputSchema,
    outputSchema: IdentifyLeafSpeciesOutputSchema,
  },
  async input => {
    const {output} = await identifyLeafSpeciesPrompt(input);
    return output!;
  }
);
