'use server';
/**
 * @fileOverview Analyzes a leaf image for signs of disease and suggests curative actions.
 *
 * - diagnoseLeafDisease - A function that handles the leaf disease diagnosis process.
 * - DiagnoseLeafDiseaseInput - The input type for the diagnoseLeafDisease function.
 * - DiagnoseLeafDiseaseOutput - The return type for the diagnoseLeafDisease function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const DiagnoseLeafDiseaseInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "A photo of a leaf, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type DiagnoseLeafDiseaseInput = z.infer<typeof DiagnoseLeafDiseaseInputSchema>;

const DiagnoseLeafDiseaseOutputSchema = z.object({
  diseaseIdentification: z.object({
    isHealthy: z.boolean().describe('Whether or not the plant is healthy.'),
    diseaseName: z.string().describe("The name of the identified disease, or 'None' if healthy."),
    confidence: z.number().describe('Confidence level of the disease identification (0-1).'),
  }),
  curativeActions: z.string().describe('Suggested curative actions to take.'),
});
export type DiagnoseLeafDiseaseOutput = z.infer<typeof DiagnoseLeafDiseaseOutputSchema>;

export async function diagnoseLeafDisease(input: DiagnoseLeafDiseaseInput): Promise<DiagnoseLeafDiseaseOutput> {
  return diagnoseLeafDiseaseFlow(input);
}

const prompt = ai.definePrompt({
  name: 'diagnoseLeafDiseasePrompt',
  input: {schema: DiagnoseLeafDiseaseInputSchema},
  output: {schema: DiagnoseLeafDiseaseOutputSchema},
  prompt: `You are an expert in plant pathology. Analyze the provided image of a leaf and determine if it shows signs of disease.

  Based on the visual characteristics of the leaf in the image, identify any potential diseases or abnormalities.  If no disease is found indicate that the plant is healthy.

  Provide specific and actionable curative actions that can be taken to address the identified disease or abnormality.

  Photo: {{media url=photoDataUri}}
  \n\
  Format your response as a JSON object that conforms to the following schema:
  ${JSON.stringify(DiagnoseLeafDiseaseOutputSchema.describe(''))}`,
});

const diagnoseLeafDiseaseFlow = ai.defineFlow(
  {
    name: 'diagnoseLeafDiseaseFlow',
    inputSchema: DiagnoseLeafDiseaseInputSchema,
    outputSchema: DiagnoseLeafDiseaseOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
