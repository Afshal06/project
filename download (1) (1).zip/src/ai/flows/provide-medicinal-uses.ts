'use server';

/**
 * @fileOverview Provides a summary of the traditional medicinal uses of a leaf.
 *
 * - provideMedicinalUses - A function that takes a leaf name and returns a summary of its medicinal uses.
 * - ProvideMedicinalUsesInput - The input type for the provideMedicinalUses function.
 * - ProvideMedicinalUsesOutput - The return type for the provideMedicinalUses function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ProvideMedicinalUsesInputSchema = z.object({
  leafName: z.string().describe('The common name of the leaf.'),
});
export type ProvideMedicinalUsesInput = z.infer<typeof ProvideMedicinalUsesInputSchema>;

const ProvideMedicinalUsesOutputSchema = z.object({
  medicinalUses: z.string().describe('A summary of the traditional medicinal uses of the leaf.'),
});
export type ProvideMedicinalUsesOutput = z.infer<typeof ProvideMedicinalUsesOutputSchema>;

export async function provideMedicinalUses(input: ProvideMedicinalUsesInput): Promise<ProvideMedicinalUsesOutput> {
  return provideMedicinalUsesFlow(input);
}

const prompt = ai.definePrompt({
  name: 'provideMedicinalUsesPrompt',
  input: {schema: ProvideMedicinalUsesInputSchema},
  output: {schema: ProvideMedicinalUsesOutputSchema},
  prompt: `You are a helpful AI assistant that summarizes the traditional medicinal uses of plants.

  Provide a concise summary of the traditional medicinal uses of {{leafName}}.`,
});

const provideMedicinalUsesFlow = ai.defineFlow(
  {
    name: 'provideMedicinalUsesFlow',
    inputSchema: ProvideMedicinalUsesInputSchema,
    outputSchema: ProvideMedicinalUsesOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
