"use client";

import { useState, useTransition, useCallback, ChangeEvent, DragEvent } from "react";
import Image from "next/image";
import { Leaf, UploadCloud, Loader2, ArrowLeft, X, Sprout } from "lucide-react";
import type { IdentifyLeafSpeciesOutput } from "@/ai/flows/identify-leaf-species";
import { useToast } from "@/hooks/use-toast";
import { analyzeLeaf } from "./actions";
import AnalysisDisplay from "@/components/analysis-display";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { getPlaceholderImage } from "@/lib/placeholder-images";

type ImageState = {
  file: File | null;
  preview: string | null;
};

const placeholderImage = getPlaceholderImage("leaf-background");

export default function Home() {
  const [image, setImage] = useState<ImageState>({ file: null, preview: null });
  const [result, setResult] = useState<IdentifyLeafSpeciesOutput | null>(null);
  const [isPending, startTransition] = useTransition();
  const [dragOver, setDragOver] = useState(false);
  const { toast } = useToast();

  const handleFileSelect = (selectedFile: File) => {
    if (selectedFile && selectedFile.type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage({ file: selectedFile, preview: reader.result as string });
      };
      reader.readAsDataURL(selectedFile);
    } else {
      toast({
        variant: "destructive",
        title: "Invalid File",
        description: "Please select an image file.",
      });
    }
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };
  
  const handleDrop = useCallback((e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  }, []);

  const handleDragEvents = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleAnalyze = () => {
    if (!image.preview) return;

    startTransition(async () => {
      const res = await analyzeLeaf({ photoDataUri: image.preview! });
      if (res.success && res.data) {
        setResult(res.data);
      } else {
        toast({
          variant: "destructive",
          title: "Analysis Failed",
          description: res.error || "An unknown error occurred.",
        });
      }
    });
  };

  const handleReset = () => {
    setImage({ file: null, preview: null });
    setResult(null);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background font-body">
      <header className="sticky top-0 bg-background/80 backdrop-blur-sm z-10">
        <div className="container mx-auto p-4 flex items-center gap-3">
          <Leaf className="w-8 h-8 text-primary" />
          <h1 className="text-3xl font-bold font-headline tracking-tight">
            LeafWise
          </h1>
        </div>
      </header>

      <main className="flex-1 container mx-auto p-4 sm:p-6 md:p-8 flex flex-col items-center">
        <div className="w-full max-w-4xl mx-auto animate-in fade-in-50 duration-500">
          {isPending ? (
            <div className="flex flex-col items-center justify-center gap-4 text-center min-h-[50vh]">
              <Loader2 className="w-16 h-16 text-primary animate-spin" />
              <h2 className="text-2xl font-semibold font-headline">Analyzing your leaf...</h2>
              <p className="text-muted-foreground">Our AI is working its magic. Please wait a moment.</p>
            </div>
          ) : result && image.preview ? (
            <AnalysisDisplay result={result} imagePreview={image.preview} onReset={handleReset} />
          ) : (
            <div className="flex flex-col gap-8">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div className="space-y-4 text-center md:text-left">
                  <h2 className="text-4xl md:text-5xl font-bold font-headline leading-tight">Welcome to LeafWise</h2>
                  <p className="text-lg text-muted-foreground">
                    Identify plants, diagnose diseases, and discover medicinal uses with a single photo.
                  </p>
                </div>
                {placeholderImage && (
                  <div className="hidden md:block">
                     <Image
                      src={placeholderImage.imageUrl}
                      alt={placeholderImage.description}
                      width={1200}
                      height={800}
                      className="rounded-xl shadow-lg"
                      data-ai-hint={placeholderImage.imageHint}
                      priority
                    />
                  </div>
                )}
              </div>

              {!image.preview ? (
                <div
                  onDrop={handleDrop}
                  onDragOver={(e) => { handleDragEvents(e); setDragOver(true); }}
                  onDragLeave={(e) => { handleDragEvents(e); setDragOver(false); }}
                  className={cn(
                    "relative group w-full p-8 border-2 border-dashed rounded-xl text-center transition-colors duration-300",
                    dragOver ? "border-primary bg-primary/10" : "border-muted-foreground/50 hover:border-primary"
                  )}
                >
                  <input
                    id="file-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center justify-center gap-4">
                    <div className="p-4 bg-primary/10 rounded-full border-8 border-primary/5 group-hover:scale-110 transition-transform">
                      <UploadCloud className="w-10 h-10 text-primary" />
                    </div>
                    <p className="text-xl font-semibold">
                      <span className="text-primary">Click to upload</span> or drag and drop a leaf image
                    </p>
                    <p className="text-muted-foreground">PNG, JPG, or WEBP accepted</p>
                  </label>
                </div>
              ) : (
                <Card className="p-6 shadow-xl animate-in fade-in-50">
                  <div className="flex flex-col md:flex-row items-center gap-6">
                    <div className="relative w-48 h-48 flex-shrink-0">
                      <Image src={image.preview} alt="Leaf preview" layout="fill" objectFit="cover" className="rounded-lg" />
                       <Button variant="destructive" size="icon" className="absolute -top-3 -right-3 rounded-full h-8 w-8 z-10" onClick={() => setImage({ file: null, preview: null })}>
                        <X className="h-4 w-4" />
                        <span className="sr-only">Remove image</span>
                      </Button>
                    </div>
                    <div className="flex-grow text-center md:text-left space-y-4">
                      <h3 className="text-2xl font-bold font-headline">Ready for Analysis</h3>
                      <p className="text-muted-foreground">Your leaf image is uploaded and ready. Click the button to start the AI analysis.</p>
                      <Button size="lg" onClick={handleAnalyze}>
                        <Sprout className="mr-2 h-5 w-5" />
                        Analyze Leaf
                      </Button>
                    </div>
                  </div>
                </Card>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
