"use server";

import { identifyLeafSpecies, type IdentifyLeafSpeciesOutput } from "@/ai/flows/identify-leaf-species";
import { z } from "zod";

const inputSchema = z.object({
  photoDataUri: z.string().startsWith("data:image/"),
});

type ActionResult = {
  success: boolean;
  data?: IdentifyLeafSpeciesOutput;
  error?: string;
};

export async function analyzeLeaf(values: z.infer<typeof inputSchema>): Promise<ActionResult> {
  const parsed = inputSchema.safeParse(values);
  if (!parsed.success) {
    return { success: false, error: "Invalid input. Please provide a valid image data URI." };
  }

  try {
    const result = await identifyLeafSpecies({ photoDataUri: parsed.data.photoDataUri });
    return { success: true, data: result };
  } catch (e) {
    console.error("Leaf analysis failed:", e);
    return { success: false, error: "The AI model failed to analyze the leaf. This could be due to a poor quality image or a temporary issue. Please try again." };
  }
}
